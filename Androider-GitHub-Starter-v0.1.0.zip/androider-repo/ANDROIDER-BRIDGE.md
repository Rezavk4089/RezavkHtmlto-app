# پل ارتباطی HTML و Android

در WebView شیء `Android` در دسترس است:

- `Android.chooseBackupFolder()` : نمایش انتخاب‌گر رسمی پوشه و ذخیره مجوز پایدار دسترسی.
- `Android.hasBackupFolder()` : بررسی اینکه پوشه‌ای قبلاً انتخاب شده است.
- `Android.backup(jsonString)` : نوشتن متن JSON در پوشه انتخاب‌شده.
- `Android.restore()` : انتخاب فایل JSON بکاپ از فایل‌منیجر.
- `Android.toast(message)` : نمایش پیام اندرویدی.

## نمونه اتصال به داده‌های LocalStorage

```html
<button onclick="Android.chooseBackupFolder()">انتخاب پوشه بکاپ</button>
<button onclick="backupNow()">تهیه بکاپ</button>
<button onclick="Android.restore()">بازیابی بکاپ</button>
<script>
function backupNow(){
  const payload={format:'androider-backup-v1',createdAt:new Date().toISOString(),storage:{}};
  for(let i=0;i<localStorage.length;i++){
    const k=localStorage.key(i); payload.storage[k]=localStorage.getItem(k);
  }
  Android.backup(JSON.stringify(payload));
}
window.onNativeRestore=function(json){
  try{
    const data=JSON.parse(json);
    if(data.format!=='androider-backup-v1'||!data.storage) throw new Error('فرمت بکاپ معتبر نیست');
    Object.keys(data.storage).forEach(k=>localStorage.setItem(k,data.storage[k]));
    Android.toast('بازیابی انجام شد؛ صفحه در حال تازه‌سازی است');
    location.reload();
  }catch(e){Android.toast('بازیابی ناموفق: '+e.message)}
};
</script>
```

## محدودیت‌های این نسخه اولیه

- پل Native و SAF برای انتخاب پوشه/فایل و نوشتن/خواندن JSON پیاده‌سازی شده است.
- این نمونه بکاپ، داده‌های `localStorage` را صادر می‌کند؛ داده‌های IndexedDB، فایل‌های داخلی برنامه یا داده‌های سمت سرور باید جداگانه به payload اضافه شوند.
- حذف خودکار بکاپ‌های قدیمی، رمزنگاری بکاپ، امضای Release و اختبارات بازیابی هنوز پیاده‌سازی نشده‌اند.
- دسترسی پایدار SAF پس از حذف برنامه تضمین نمی‌شود؛ پس از نصب مجدد ممکن است کاربر لازم باشد فایل بکاپ را دوباره از فایل‌منیجر انتخاب کند.
- این پروژه یک قالب اجرایی اولیه است و پیش از استفاده با داده مالی واقعی باید روی دستگاه آزمایش شود.
