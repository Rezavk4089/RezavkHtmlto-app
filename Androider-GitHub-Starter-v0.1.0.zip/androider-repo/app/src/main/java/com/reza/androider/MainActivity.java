package com.reza.androider;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.webkit.*;
import android.widget.Toast;
import android.database.Cursor;
import android.provider.OpenableColumns;
import android.content.SharedPreferences;
import android.content.Context;
import java.io.*;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int PICK_BACKUP_DIR=4101, PICK_RESTORE_FILE=4102;
    private WebView web; private SharedPreferences prefs; private Uri pendingRestore;
    @Override public void onCreate(Bundle b){super.onCreate(b); prefs=getSharedPreferences("androider",MODE_PRIVATE); web=new WebView(this); setContentView(web);
        WebSettings s=web.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true); s.setSupportZoom(true);
        web.addJavascriptInterface(new Bridge(),"Android"); web.setWebViewClient(new WebViewClient()); web.loadUrl("file:///android_asset/index.html"); }
    public class Bridge {
        @JavascriptInterface public void chooseBackupFolder(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE); i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION); startActivityForResult(i,PICK_BACKUP_DIR);});}
        @JavascriptInterface public boolean hasBackupFolder(){return prefs.contains("tree");}
        @JavascriptInterface public void backup(String json){runOnUiThread(()->writeBackup(json));}
        @JavascriptInterface public void restore(){runOnUiThread(()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");startActivityForResult(i,PICK_RESTORE_FILE);});}
        @JavascriptInterface public void toast(String m){runOnUiThread(()->Toast.makeText(MainActivity.this,m,Toast.LENGTH_LONG).show());}
        @JavascriptInterface public void sendToPage(String json){runOnUiThread(()->web.evaluateJavascript("window.onNativeRestore && window.onNativeRestore("+JSONObjectSafe.quote(json)+")",null));}
    }
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(res!=RESULT_OK||data==null)return;Uri u=data.getData();if(req==PICK_BACKUP_DIR){int flags=data.getFlags()&(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);try{getContentResolver().takePersistableUriPermission(u,flags);prefs.edit().putString("tree",u.toString()).apply();Toast.makeText(this,"مسیر بکاپ ذخیره شد",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"ذخیره مجوز پوشه ناموفق بود",Toast.LENGTH_LONG).show();}}
        if(req==PICK_RESTORE_FILE){try(InputStream in=getContentResolver().openInputStream(u)){byte[] bytes=readAll(in);String json=new String(bytes,StandardCharsets.UTF_8);web.evaluateJavascript("window.onNativeRestore && window.onNativeRestore("+JSONObjectSafe.quote(json)+")",null);}catch(Exception e){Toast.makeText(this,"خواندن بکاپ ناموفق بود",Toast.LENGTH_LONG).show();}}}
    private void writeBackup(String json){String tree=prefs.getString("tree",null);if(tree==null){Toast.makeText(this,"ابتدا مسیر بکاپ را انتخاب کن",Toast.LENGTH_LONG).show();return;}try{androidxPlaceholder();}catch(Exception ignored){} try{android.provider.DocumentsContract.Document document=null; Uri dir=Uri.parse(tree); String name="androider-backup-"+System.currentTimeMillis()+".json"; Uri file=android.provider.DocumentsContract.createDocument(getContentResolver(),dir,"application/json",name);if(file==null)throw new IOException("createDocument returned null");try(OutputStream out=getContentResolver().openOutputStream(file,"w")){out.write(json.getBytes(StandardCharsets.UTF_8));out.flush();}Toast.makeText(this,"بکاپ با موفقیت ذخیره شد",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"خطا در ذخیره بکاپ: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    private void androidxPlaceholder(){}
    private byte[] readAll(InputStream in)throws IOException{ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] x=new byte[8192];int n;while((n=in.read(x))>0)b.write(x,0,n);return b.toByteArray();}
    @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
    static class JSONObjectSafe { static String quote(String s){StringBuilder b=new StringBuilder("\"");for(char c:s.toCharArray()){switch(c){case '\\':b.append("\\\\");break;case '"':b.append("\\\"");break;case '\n':b.append("\\n");break;case '\r':b.append("\\r");break;case '<':b.append("\\u003c");break;default:b.append(c);}}return b.append('"').toString();}}
}
