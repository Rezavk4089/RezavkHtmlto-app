from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path, PurePosixPath
import tempfile, zipfile, shutil, os, re, subprocess, uuid
from starlette.background import BackgroundTask

BASE = Path(__file__).resolve().parent.parent
TEMPLATE = BASE / "android-template"
WEB = BASE / "web"
MAX_UPLOAD = int(os.getenv("MAX_UPLOAD_MB", "100")) * 1024 * 1024
BUILD_TIMEOUT = int(os.getenv("BUILD_TIMEOUT_SECONDS", "900"))

app = FastAPI(title="RezavkHtml2App Build API", version="2.0.0")

def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9 _-]", "", value or "").strip()
    return (value[:40] or "My HTML App")

def validate_package(value: str) -> str:
    value = (value or "").strip()
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*){1,}", value):
        raise HTTPException(400, "شناسه بسته معتبر نیست؛ نمونه: com.example.myapp")
    return value

def safe_extract(zip_path: Path, dest: Path):
    with zipfile.ZipFile(zip_path) as zf:
        entries = zf.infolist()
        if len(entries) > 5000:
            raise HTTPException(400, "تعداد فایل‌های ZIP بیش از حد مجاز است.")
        total = 0
        for info in entries:
            p = PurePosixPath(info.filename)
            if p.is_absolute() or ".." in p.parts or not p.parts:
                raise HTTPException(400, "مسیر ناامن داخل ZIP شناسایی شد.")
            # Reject Unix symlinks.
            mode = (info.external_attr >> 16) & 0xFFFF
            if (mode & 0o170000) == 0o120000:
                raise HTTPException(400, "فایل پیوندی داخل ZIP مجاز نیست.")
            total += info.file_size
            if total > MAX_UPLOAD * 5:
                raise HTTPException(400, "حجم بازشده ZIP بیش از حد مجاز است.")
        zf.extractall(dest)

def locate_site(folder: Path) -> Path:
    candidates = list(folder.rglob("index.html")) + list(folder.rglob("index.htm"))
    candidates = [p for p in candidates if p.is_file()]
    if not candidates:
        raise HTTPException(400, "در ZIP فایل index.html یا index.htm پیدا نشد.")
    # Prefer root index; otherwise accept a single project root.
    root_index = folder / "index.html"
    if root_index.exists():
        return folder
    root_htm = folder / "index.htm"
    if root_htm.exists():
        return folder
    parents = {p.parent for p in candidates}
    if len(parents) != 1:
        raise HTTPException(400, "چند فایل index.html پیدا شد؛ پروژه را در یک پوشه اصلی ZIP قرار بده.")
    return next(iter(parents))

def make_gradle_project(work: Path, app_name: str, package_id: str, site_dir: Path):
    shutil.copytree(TEMPLATE, work, dirs_exist_ok=True)
    app = work / "app"
    java_dir = app / "src/main/java" / Path(*package_id.split("."))
    java_dir.mkdir(parents=True, exist_ok=True)
    (java_dir / "MainActivity.java").write_text(
        (TEMPLATE / "MainActivity.java.in").read_text().replace("__PACKAGE__", package_id),
        encoding="utf-8"
    )
    (app / "src/main/AndroidManifest.xml").write_text(
        (TEMPLATE / "AndroidManifest.xml.in").read_text().replace("__PACKAGE__", package_id),
        encoding="utf-8"
    )
    (app / "build.gradle").write_text(
        (TEMPLATE / "app/build.gradle.in").read_text().replace("__PACKAGE__", package_id),
        encoding="utf-8"
    )
    shutil.rmtree(app / "src/main/assets/site", ignore_errors=True)
    shutil.copytree(site_dir, app / "src/main/assets/site")
    # Android's resource string is escaped via XML entities.
    (app / "src/main/res/values/strings.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n<resources><string name="app_name">' +
        app_name.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;") +
        '</string></resources>\n', encoding="utf-8"
    )

@app.get("/api/health")
def health():
    return {"ok": True, "name": "RezavkHtml2App", "version": "2.0.0"}

@app.post("/api/build")
async def build(
    file: UploadFile = File(...),
    app_name: str = Form("HTML App"),
    package_id: str = Form("com.reza.htmlapp")
):
    package_id = validate_package(package_id)
    app_name = safe_name(app_name)
    suffix = Path(file.filename or "").suffix.lower()
    if suffix not in (".html", ".htm", ".zip"):
        raise HTTPException(400, "فقط فایل HTML یا ZIP پذیرفته می‌شود.")
    job = Path(tempfile.mkdtemp(prefix="reza-build-"))
    try:
        upload = job / ("input" + suffix)
        size = 0
        with upload.open("wb") as out:
            while True:
                chunk = await file.read(1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_UPLOAD:
                    raise HTTPException(413, f"حداکثر حجم آپلود {MAX_UPLOAD // (1024*1024)} مگابایت است.")
                out.write(chunk)
        source = job / "source"
        source.mkdir()
        if suffix == ".zip":
            try:
                safe_extract(upload, source)
            except zipfile.BadZipFile:
                raise HTTPException(400, "فایل ZIP معتبر نیست.")
            site = locate_site(source)
        else:
            site = source
            shutil.copy2(upload, site / "index.html")

        project = job / "android-project"
        make_gradle_project(project, app_name, package_id, site)
        proc = subprocess.run(
            ["gradle", "--no-daemon", "--stacktrace", "assembleDebug"],
            cwd=project, capture_output=True, text=True, timeout=BUILD_TIMEOUT
        )
        apk = project / "app/build/outputs/apk/debug/app-debug.apk"
        if proc.returncode != 0 or not apk.exists():
            tail = (proc.stdout + "\n" + proc.stderr)[-12000:]
            raise HTTPException(500, "ساخت APK ناموفق بود:\n" + tail)
        final_apk = job / (re.sub(r"[^A-Za-z0-9_-]", "_", app_name) + "-debug.apk")
        shutil.copy2(apk, final_apk)
        # FileResponse streams the artifact; background cleanup after response.
        return FileResponse(
            final_apk, media_type="application/vnd.android.package-archive",
            filename=final_apk.name,
            background=BackgroundTask(shutil.rmtree, job, ignore_errors=True)
        )
    except subprocess.TimeoutExpired:
        raise HTTPException(504, "زمان ساخت APK تمام شد. پروژه بزرگ است یا سرور کند است.")

app.mount("/", StaticFiles(directory=WEB, html=True), name="web")
