const fileInput=document.getElementById('file'),label=document.getElementById('fileLabel'),btn=document.getElementById('build'),statusBox=document.getElementById('status');
fileInput.addEventListener('change',()=>{const f=fileInput.files[0];label.textContent=f?`${f.name} · ${(f.size/1048576).toFixed(2)} MB`:'انتخاب HTML یا ZIP';});
btn.addEventListener('click',async()=>{
 const f=fileInput.files[0];if(!f){statusBox.textContent='ابتدا یک فایل HTML یا ZIP انتخاب کن.';return;}
 const name=document.getElementById('appName').value.trim()||'برنامه من';
 const pkg=document.getElementById('packageId').value.trim();
 if(!/^[A-Za-z][A-Za-z0-9_]*(\.[A-Za-z][A-Za-z0-9_]*)+$/.test(pkg)){statusBox.textContent='شناسه بسته معتبر نیست. نمونه: com.reza.myapp';return;}
 const data=new FormData();data.append('file',f);data.append('app_name',name);data.append('package_id',pkg);
 btn.disabled=true;statusBox.textContent='مرحله ۱ از ۳: ارسال فایل...';
 try{
  statusBox.textContent='مرحله ۲ از ۳: موتور در حال ساخت پروژه Android و کامپایل APK است. این کار ممکن است چند دقیقه طول بکشد...';
  const res=await fetch('/api/build',{method:'POST',body:data});
  if(!res.ok){let msg=await res.text();try{msg=JSON.parse(msg).detail||msg}catch{}throw new Error(msg);}
  const blob=await res.blob();const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=(name.replace(/[^A-Za-z0-9_-]/g,'_')||'app')+'-debug.apk';document.body.appendChild(a);a.click();a.remove();URL.revokeObjectURL(url);
  statusBox.textContent='مرحله ۳ از ۳: فایل APK ساخته شد و دانلود آن آغاز شد. قبل از استفاده اصلی، روی گوشی نصب و آزمایش کن.';
 }catch(e){statusBox.textContent='ساخت ناموفق بود:\n'+e.message;}
 finally{btn.disabled=false;}
});
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('/sw.js').catch(()=>{});
