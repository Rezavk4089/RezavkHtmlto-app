# RezavkHtml2App 2.0.0 — Source Project

A practical HTML/ZIP-to-APK builder with:
- Persian RTL PWA interface (installable on Android when served over HTTPS)
- FastAPI build service
- Android WebView wrapper template
- Docker image containing JDK, Android SDK and Gradle

## Important architecture note
The phone UI is the client. APK compilation runs on the build server because Android SDK/Gradle are required. This repository is source code; it does not contain a prebuilt APK or a deployed public build server.

## Run locally (Linux/macOS with Docker)
```bash
docker compose up --build
```
Open `http://localhost:8080`.

For phone access, deploy this service to a server with Docker and HTTPS, then open its URL on Android and use "Add to Home screen".

## Build input
- `.html` / `.htm`: used as `index.html`
- `.zip`: extracted safely; must contain `index.html` at the root or in one unambiguous top-level folder
- CSS, JS, images, fonts and other files are copied into the APK assets unchanged

## API
- `GET /api/health`
- `POST /api/build` multipart form:
  - `file`: HTML or ZIP
  - `app_name`: display name
  - `package_id`: Android application ID, e.g. `com.example.myapp`
Returns an APK attachment on success.

## Limits and security
- `MAX_UPLOAD_MB` defaults to 100.
- ZIP path traversal and symlink entries are rejected.
- This is an MVP. Before public production use, add authentication, per-user quotas, job isolation, rate limiting, malware scanning and persistent job storage.
- Debug APKs are signed with Android's debug key. A production release requires a user-owned signing key and secure signing workflow.
