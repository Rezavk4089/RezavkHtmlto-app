# RezavkHtml2App - Android project

Generated project for **Rvk.htmltoapp**.

## Build APK with GitHub Actions
1. Extract this ZIP.
2. Upload all extracted files and folders to the root of a GitHub repository (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build Android APK** and click **Run workflow**, or push to main/master.
5. Open the completed run and download the artifact ending in **debug-apk**.

## Build locally
Requires JDK 17, Android SDK platform 35 and Gradle 8.9+. Run gradle assembleDebug.

## Important limitations
- The source HTML is copied to app/src/main/assets/index.html. This is a WebView wrapper project, not a native rewrite.
- This version packages the selected HTML file only. External CSS/JS/images/fonts referenced by separate files are not collected; embed them in the HTML before import.
- Debug APK is for testing. A signed release APK/AAB requires a signing key and a separate release configuration.
- Test file upload/download behavior on the target device; Internet permission is added automatically when offline mode is disabled.
