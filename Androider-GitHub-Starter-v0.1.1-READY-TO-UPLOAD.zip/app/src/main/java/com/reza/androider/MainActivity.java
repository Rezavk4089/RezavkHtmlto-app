package com.reza.androider;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends Activity {
    private static final int PICK_BACKUP_DIR = 4101;
    private static final int PICK_RESTORE_FILE = 4102;
    private static final String PREF_TREE = "backup_tree_uri";
    private static final String BACKUP_PREFIX = "androider-backup-";
    private static final int MAX_BACKUP_BYTES = 50 * 1024 * 1024;
    private static final int KEEP_BACKUPS = 2;

    private WebView web;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences("androider", MODE_PRIVATE);

        web = new WebView(this);
        setContentView(web);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setSupportZoom(true);
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidBridge(), "Android");
        web.loadUrl("file:///android_asset/index.html");
    }

    public final class AndroidBridge {
        @JavascriptInterface
        public void chooseBackupFolder() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_BACKUP_DIR);
            });
        }

        @JavascriptInterface
        public boolean hasBackupFolder() {
            String tree = prefs.getString(PREF_TREE, null);
            if (tree == null || tree.isEmpty()) return false;
            Uri savedUri = Uri.parse(tree);
            for (android.content.UriPermission permission : getContentResolver().getPersistedUriPermissions()) {
                if (savedUri.equals(permission.getUri()) && permission.isWritePermission()) return true;
            }
            return false;
        }

        @JavascriptInterface
        public void backup(String json) {
            if (json == null || json.trim().isEmpty()) {
                showToast("اطلاعات بکاپ خالی است");
                return;
            }
            if (json.getBytes(StandardCharsets.UTF_8).length > MAX_BACKUP_BYTES) {
                showToast("حجم بکاپ بیش از ۵۰ مگابایت است");
                return;
            }
            runOnUiThread(() -> writeBackup(json));
        }

        @JavascriptInterface
        public void restore() {
            runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                        | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
                startActivityForResult(intent, PICK_RESTORE_FILE);
            });
        }

        @JavascriptInterface
        public void toast(String message) {
            showToast(message == null ? "" : message);
        }
    }

    private void showToast(String message) {
        runOnUiThread(() -> Toast.makeText(this, message, Toast.LENGTH_LONG).show());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != PICK_BACKUP_DIR && requestCode != PICK_RESTORE_FILE) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            showToast("انتخاب فایل یا پوشه لغو شد");
            return;
        }

        Uri uri = data.getData();
        if (requestCode == PICK_BACKUP_DIR) {
            int grantedFlags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION
                    | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            try {
                if ((grantedFlags & Intent.FLAG_GRANT_WRITE_URI_PERMISSION) == 0) {
                    throw new SecurityException("مجوز نوشتن برای پوشه صادر نشد");
                }
                getContentResolver().takePersistableUriPermission(uri, grantedFlags);
                prefs.edit().putString(PREF_TREE, uri.toString()).apply();
                showToast("مسیر بکاپ ذخیره شد");
            } catch (Exception error) {
                showToast("ذخیره دسترسی پوشه ناموفق بود: " + safeMessage(error));
            }
        } else {
            restoreFrom(uri);
        }
    }

    private void writeBackup(String json) {
        String tree = prefs.getString(PREF_TREE, null);
        if (tree == null || tree.isEmpty()) {
            showToast("ابتدا مسیر بکاپ را انتخاب کن");
            return;
        }

        Uri file = null;
        try {
            new JSONObject(json);
            Uri directory = Uri.parse(tree);
            String fileName = BACKUP_PREFIX + System.currentTimeMillis() + ".json";
            file = DocumentsContract.createDocument(
                    getContentResolver(), directory, "application/json", fileName);
            if (file == null) throw new IOException("ساخت فایل بکاپ ناموفق بود");

            try (OutputStream output = getContentResolver().openOutputStream(file, "w")) {
                if (output == null) throw new IOException("باز کردن فایل برای نوشتن ناموفق بود");
                output.write(json.getBytes(StandardCharsets.UTF_8));
                output.flush();
            }

            boolean cleanupSucceeded = keepLatestBackups(directory);
            showToast(cleanupSucceeded
                    ? "بکاپ ذخیره شد؛ حداکثر دو نسخه نگهداری می‌شود"
                    : "بکاپ ذخیره شد؛ پاک‌سازی نسخه‌های قدیمی انجام نشد");
        } catch (Exception error) {
            if (file != null) {
                try { DocumentsContract.deleteDocument(getContentResolver(), file); }
                catch (Exception ignored) { }
            }
            showToast("خطا در ذخیره بکاپ: " + safeMessage(error));
        }
    }

    private boolean keepLatestBackups(Uri treeUri) {
        Cursor cursor = null;
        try {
            String treeDocumentId = DocumentsContract.getTreeDocumentId(treeUri);
            Uri childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, treeDocumentId);
            String[] projection = {
                    DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                    DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                    DocumentsContract.Document.COLUMN_LAST_MODIFIED
            };
            cursor = getContentResolver().query(childrenUri, projection, null, null, null);
            if (cursor == null) return false;

            List<BackupDocument> backups = new ArrayList<>();
            while (cursor.moveToNext()) {
                String name = cursor.getString(1);
                if (name != null && name.startsWith(BACKUP_PREFIX) && name.endsWith(".json")) {
                    String documentId = cursor.getString(0);
                    long modified = cursor.isNull(2) ? 0L : cursor.getLong(2);
                    backups.add(new BackupDocument(
                            DocumentsContract.buildDocumentUriUsingTree(treeUri, documentId), modified));
                }
            }
            backups.sort(Comparator.comparingLong((BackupDocument item) -> item.modified).reversed());
            for (int i = KEEP_BACKUPS; i < backups.size(); i++) {
                DocumentsContract.deleteDocument(getContentResolver(), backups.get(i).uri);
            }
            return true;
        } catch (Exception error) {
            return false;
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    private void restoreFrom(Uri uri) {
        try (InputStream input = getContentResolver().openInputStream(uri)) {
            if (input == null) throw new IOException("خواندن فایل ممکن نیست");
            byte[] bytes = readAll(input);
            if (bytes.length > MAX_BACKUP_BYTES) throw new IOException("حجم فایل بیش از ۵۰ مگابایت است");
            String json = new String(bytes, StandardCharsets.UTF_8);
            new JSONObject(json);
            String script = "if (typeof window.onNativeRestore === 'function') { window.onNativeRestore("
                    + JSONObject.quote(json) + "); } else { Android.toast('تابع بازیابی در صفحه پیدا نشد'); }";
            web.evaluateJavascript(script, null);
        } catch (Exception error) {
            showToast("بازیابی ناموفق بود: " + safeMessage(error));
        }
    }

    private byte[] readAll(InputStream input) throws IOException {
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        byte[] buffer = new byte[8192];
        int count;
        while ((count = input.read(buffer)) != -1) {
            output.write(buffer, 0, count);
            if (output.size() > MAX_BACKUP_BYTES) throw new IOException("حجم فایل بیش از حد مجاز است");
        }
        return output.toByteArray();
    }

    private String safeMessage(Exception error) {
        String message = error.getMessage();
        return message == null || message.trim().isEmpty() ? error.getClass().getSimpleName() : message;
    }

    private static final class BackupDocument {
        final Uri uri;
        final long modified;
        BackupDocument(Uri uri, long modified) {
            this.uri = uri;
            this.modified = modified;
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
