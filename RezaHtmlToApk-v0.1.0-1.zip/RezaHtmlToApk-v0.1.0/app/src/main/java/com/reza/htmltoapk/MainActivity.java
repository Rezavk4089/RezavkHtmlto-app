package com.reza.htmltoapk;
import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class MainActivity extends Activity {
 private WebView webView;
 @Override public void onCreate(Bundle savedInstanceState) {
  super.onCreate(savedInstanceState);
  webView = new WebView(this);
  WebSettings s = webView.getSettings();
  s.setJavaScriptEnabled(true);
  s.setDomStorageEnabled(true);
  s.setAllowFileAccess(true);
  s.setAllowContentAccess(true);
  webView.setWebViewClient(new WebViewClient());
  webView.setWebChromeClient(new WebChromeClient());
  setContentView(webView);
  webView.loadUrl("file:///android_asset/index.html");
 }
 @Override public void onBackPressed() {
  if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
 }
 @Override protected void onDestroy() {
  if (webView != null) { webView.destroy(); webView = null; }
  super.onDestroy();
 }
}
