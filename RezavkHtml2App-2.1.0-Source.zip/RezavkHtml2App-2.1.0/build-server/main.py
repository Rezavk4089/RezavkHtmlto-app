import os, re, uuid, shutil, zipfile, stat, subprocess, time
from pathlib import Path
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.responses import FileResponse
from fastapi.middleware.cors import CORSMiddleware

BASE = Path("/srv")
JOBS = BASE / "jobs"
TEMPLATE = BASE / "android-template"
MAX_MB = int(os.getenv("MAX_UPLOAD_MB", "100"))
JOBS.mkdir(parents=True, exist_ok=True)
TTL_HOURS = int(os.getenv("JOB_TTL_HOURS", "12"))

def cleanup_old_jobs():
    cutoff = time.time() - TTL_HOURS * 3600
    for item in JOBS.iterdir():
        try:
            if item.is_dir() and item.stat().st_mtime < cutoff:
                shutil.rmtree(item, ignore_errors=True)
        except OSError:
            pass

app = FastAPI(title="RezavkHtml2App Build Engine", version="2.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["GET","POST"], allow_headers=["*"])

def safe_extract(zf: zipfile.ZipFile, dest: Path):
    infos = zf.infolist()
    if len(infos) > 5000:
        raise ValueError("تعداد فایل‌های ZIP بیش از حد مجاز است.")
    total = 0
    for info in infos:
        name = info.filename.replace("\\", "/")
        p = Path(name)
        mode = info.external_attr >> 16
        if p.is_absolute() or ".." in p.parts or (mode and stat.S_ISLNK(mode)):
            raise ValueError("ZIP شامل مسیر یا پیوند غیرمجاز است.")
        total += info.file_size
        if total > MAX_MB * 1024 * 1024 * 5:
            raise ValueError("حجم استخراج‌شده ZIP بیش از حد مجاز است.")
        target = (dest / p).resolve()
        if dest.resolve() not in target.parents and target != dest.resolve():
            raise ValueError("مسیر فایل ZIP معتبر نیست.")
        if info.is_dir():
            target.mkdir(parents=True, exist_ok=True)
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, target.open("wb") as out:
                shutil.copyfileobj(src, out)

def find_site(root: Path) -> Path:
    if (root / "index.html").is_file() or (root / "index.htm").is_file():
        return root
    dirs = [p for p in root.iterdir() if p.is_dir()]
    candidates = [p for p in dirs if (p / "index.html").is_file() or (p / "index.htm").is_file()]
    if len(candidates) == 1:
        return candidates[0]
    raise ValueError("در ZIP باید index.html در ریشه یا تنها پوشه اصلی وجود داشته باشد.")

def render_template(text: str, package_id: str, app_name: str) -> str:
    return text.replace("__PACKAGE__", package_id).replace("__APP_NAME__", app_name)

@app.get("/api/health")
def health():
    cleanup_old_jobs()
    return {"ok": True, "service": "RezavkHtml2App", "version": "2.1.0"}

@app.post("/api/build")
async def build(source: UploadFile = File(...), app_name: str = Form(...), package_id: str = Form(...)):
    if not re.fullmatch(r"[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,5}", package_id):
        raise HTTPException(400, "شناسه بسته معتبر نیست.")
    if not app_name.strip() or len(app_name) > 40:
        raise HTTPException(400, "نام برنامه باید بین ۱ تا ۴۰ نویسه باشد.")
    suffix = Path(source.filename or "").suffix.lower()
    if suffix not in (".zip", ".html", ".htm"):
        raise HTTPException(400, "فقط فایل HTML یا ZIP پذیرفته می‌شود.")
    job_id = uuid.uuid4().hex
    job = JOBS / job_id
    incoming = job / "incoming"
    project = job / "project"
    site = job / "site"
    job.mkdir(parents=True)
    try:
        data = await source.read(MAX_MB * 1024 * 1024 + 1)
        if not data or len(data) > MAX_MB * 1024 * 1024:
            raise ValueError(f"حجم فایل باید حداکثر {MAX_MB} مگابایت باشد.")
        incoming.mkdir()
        upload_path = incoming / ("source" + suffix)
        upload_path.write_bytes(data)
        if suffix == ".zip":
            site.mkdir()
            with zipfile.ZipFile(upload_path) as zf:
                safe_extract(zf, site)
            site_root = find_site(site)
        else:
            site_root = site
            site_root.mkdir()
            (site_root / ("index.html" if suffix == ".html" else "index.htm")).write_bytes(data)

        shutil.copytree(TEMPLATE, project)
        assets = project / "app" / "src" / "main" / "assets" / "site"
        assets.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(site_root, assets)
        (project / "settings.gradle").write_text((project / "settings.gradle").read_text().replace("__APP_NAME__", app_name), encoding="utf-8")
        for rel in ["app/build.gradle", "app/src/main/AndroidManifest.xml"]:
            p = project / rel
            p.write_text(render_template(p.read_text(encoding="utf-8"), package_id, app_name), encoding="utf-8")
        (project / "app/src/main/java/__PACKAGE_PATH__").mkdir(parents=True, exist_ok=True)
        java_template = project / "app/src/main/java/__PACKAGE_PATH__/MainActivity.java.in"
        java_text = java_template.read_text(encoding="utf-8").replace("__PACKAGE__", package_id)
        target_java = project / "app/src/main/java" / Path(package_id.replace(".", "/")) / "MainActivity.java"
        target_java.parent.mkdir(parents=True, exist_ok=True)
        target_java.write_text(java_text, encoding="utf-8")
        java_template.unlink()
        shutil.rmtree(project / "app/src/main/java/__PACKAGE_PATH__", ignore_errors=True)

        result = subprocess.run(["gradle", "--no-daemon", "assembleDebug"], cwd=project,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, timeout=900)
        if result.returncode != 0:
            (job / "build.log").write_text(result.stdout[-30000:], encoding="utf-8")
            raise RuntimeError("کامپایل اندروید ناموفق بود. شناسه خطا: " + job_id)
        apk = project / "app/build/outputs/apk/debug/app-debug.apk"
        if not apk.is_file():
            raise RuntimeError("Gradle موفق بود اما APK خروجی پیدا نشد.")
        shutil.copy2(apk, job / "output.apk")
        return {"ok": True, "job_id": job_id, "version": "2.1.0",
                "download_url": f"/api/download/{job_id}", "apk_type": "debug"}
    except ValueError as e:
        shutil.rmtree(job, ignore_errors=True)
        raise HTTPException(400, str(e))
    except subprocess.TimeoutExpired:
        shutil.rmtree(job, ignore_errors=True)
        raise HTTPException(504, "زمان ساخت APK بیش از ۱۵ دقیقه شد.")
    except RuntimeError as e:
        raise HTTPException(500, str(e))
    except zipfile.BadZipFile:
        shutil.rmtree(job, ignore_errors=True)
        raise HTTPException(400, "فایل ZIP خراب یا ناقص است.")
    except Exception as e:
        shutil.rmtree(job, ignore_errors=True)
        raise HTTPException(500, "خطای داخلی موتور ساخت: " + str(e))

@app.get("/api/download/{job_id}")
def download(job_id: str):
    cleanup_old_jobs()
    if not re.fullmatch(r"[a-f0-9]{32}", job_id):
        raise HTTPException(400, "شناسه ساخت معتبر نیست.")
    apk = JOBS / job_id / "output.apk"
    if not apk.is_file():
        raise HTTPException(404, "فایل APK پیدا نشد یا منقضی شده است.")
    return FileResponse(apk, media_type="application/vnd.android.package-archive",
                        filename="converted-app-debug.apk")
