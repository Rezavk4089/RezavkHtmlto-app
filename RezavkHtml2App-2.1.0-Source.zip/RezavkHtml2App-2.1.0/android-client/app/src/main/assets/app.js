const $=id=>document.getElementById(id);
const source=$("source"), statusBox=$("status"), buildBtn=$("build"), downloadArea=$("downloadArea");
source.addEventListener("change",()=>{$("fileName").textContent=source.files[0]?source.files[0].name:"هنوز فایلی انتخاب نشده است";});
$("server").value=localStorage.getItem("buildServer")||"";
function setStatus(message){statusBox.textContent=message;}
function validPackage(v){return /^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*){1,5}$/.test(v);}
buildBtn.addEventListener("click",async()=>{
 const file=source.files[0],name=$("appName").value.trim(),pkg=$("packageId").value.trim(),server=$("server").value.trim().replace(/\/+$/,"");
 downloadArea.innerHTML="";
 if(!file){setStatus("ابتدا فایل HTML یا ZIP را انتخاب کن.");return;}
 if(!name){setStatus("نام برنامه را وارد کن.");return;}
 if(!validPackage(pkg)){setStatus("شناسه بسته معتبر نیست؛ نمونه: com.company.myapp");return;}
 if(!/^https?:\/\//i.test(server)){setStatus("نشانی کامل سرور را با https:// وارد کن.");return;}
 localStorage.setItem("buildServer",server);
 const data=new FormData();data.append("source",file);data.append("app_name",name);data.append("package_id",pkg);
 buildBtn.disabled=true;setStatus("فایل در حال ارسال به موتور ساخت است…");
 try{
   const response=await fetch(server+"/api/build",{method:"POST",body:data});
   const result=await response.json().catch(()=>({detail:"پاسخ سرور قابل خواندن نیست"}));
   if(!response.ok)throw new Error(result.detail||("خطای سرور: "+response.status));
   if(!result.download_url)throw new Error("سرور لینک دریافت APK برنگرداند.");
   setStatus("ساخت APK با موفقیت در سرور تمام شد. دانلود را شروع کن.");
   const link=document.createElement("a");link.href=server+result.download_url;link.textContent="دریافت APK ساخته‌شده";link.download="";downloadArea.appendChild(link);
 }catch(e){setStatus("ساخت انجام نشد: "+e.message);}
 finally{buildBtn.disabled=false;}
});
